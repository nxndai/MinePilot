minepilot.registerPanel('hello', 'Hello Panel', '这个面板来自插件市场示例。它没有联网权限，只展示文本。');
minepilot.registerCommand('hello', '打个招呼', () => { minepilot.toast('Hello from a plugin!', 'ok'); return '示例插件运行正常'; });
